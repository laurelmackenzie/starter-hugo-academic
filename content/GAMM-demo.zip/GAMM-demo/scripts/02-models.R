# Run models and save output
# Input: /data/DA_r.rds
# Output: /models/*.rds

library(here) # The here() package allows for relative path names, without hard coding.
library(mgcv) # The mgvc() package provides functions for generalized additive (mixed) modeling.

# Run the previous script in the analysis chain to prepare data.
source(here("scripts", "01-prepare-data.R"))

# Load in the prepared data object.
DA_r <- readRDS(here("data", "DA_r.rds"))

# Model 1: smoothed fixed effect of year
# No random effects because they can take >1 hour to run
DA_r_GAMM_year <-
  bam(dep.var ~
        s(year, k = 10),
      data = DA_r,
      family = "binomial",
      method = "ML")
# Write model object to file.
saveRDS(DA_r_GAMM_year, here("models", "DA-r-GAMM-year.rds"))

# Model 2: smoothed fixed effect of year
# by style (onscreen / narration)
# No random effects because they can take >1 hour to run
DA_r_GAMM_year_style <-
  bam(dep.var ~
        s(year, k = 10, by = style.grouped),
      data = DA_r,
      family = "binomial",
      method = "ML")
# Write model object to file.
saveRDS(DA_r_GAMM_year_style, here("models", "DA-r-GAMM-year-style.rds"))

# Model 3: smoothed fixed effect of year
# by style (onscreen / narration),
# with a random intercept of word
# (Uncomment and run this at home if you want!)
# DA_r_GAMM_year_style_word <-
#   bam(dep.var ~
#         s(year, k = 10, by = style.grouped) +
#         s(word, bs = "re"),
#       data = DA_r,
#       family = "binomial",
#       method = "ML")
# Write model object to file.
# saveRDS(DA_r_GAMM_year_style_word, here("models", "DA-r-GAMM-year-style-word.rds"))