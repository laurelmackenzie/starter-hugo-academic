# Make figures for visualization
# Input: /data/DA_r.rds
# Output: /figures/*.png

library(here) # The here() package allows for relative path names, without hard coding.
library(itsadug) # The itsadug() package provides functions for visualizing GAMMs.

# Run the previous script in the analysis chain to generate model objects.
source(here("scripts", "02-models.R"))

# Load in the model objects.
DA_r_GAMM_year <- readRDS(here("data", "DA-r-GAMM-year.rds"))
DA_r_GAMM_year_style <- readRDS(here("data", "DA-r-GAMM-year-style.rds"))
DA_r_GAMM_year_style_word <- readRDS(here("data", "DA-r-GAMM-year-style-word.rds"))

# Plot of Model 1: smoothed fixed effect of year
png(filename = here("figures", "DA-r-GAMM-year.png"), width = 12, height = 6, units = "in", res = 256)
plot_smooth(DA_r_GAMM_year, 
            view = "year",
            transform = plogis,
            xlab = "Year",
            ylab = "Probability of tap", 
            ylim = c(0, 1))
dev.off()

# Plot of Model 2: smoothed fixed effect of year by style
png(filename = here("figures", "DA-r-GAMM-year-style.png"), width = 12, height = 6, units = "in", res = 256)
plot_smooth(DA_r_GAMM_year_style, 
            view = "year",
            plot_all = "style.grouped",
            transform = plogis, 
            xlab = "Year",
            ylab = "Probability of tap", 
            ylim = c(0, 1),
            hide.label = T)
dev.off()

# Plot of Model 3: smoothed fixed effect of year by style, random effect of word
png(filename = here("figures", "DA-r-GAMM-year-style-word.png"), width = 12, height = 6, units = "in", res = 256)
plot_smooth(DA_r_GAMM_year_style_word, 
            view = "year",
            plot_all = "style.grouped",
            transform = plogis, 
            xlab = "Year",
            ylab = "Probability of tap", 
            ylim = c(0, 1),
            hide.label = T)
dev.off()