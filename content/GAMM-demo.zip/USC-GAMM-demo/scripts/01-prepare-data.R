# Prepare data file
# Input: /data/Attenborough_r.csv
# Output: /data/DA_r.rds

library(here) # The here() package allows for relative path names, without hard coding.
library(tidyverse) # The tidyverse family of packages provide user-friendly routines for modeling, transforming, and visualizing data.

# Read in the data file on Attenborough's word-internal /r/-tapping,
# ensuring that numeric columns are input as type "double" (i.e. decimal).
DA_r <- read_csv(here("data", "Attenborough_r.csv"), col_types = 
                   cols(.default = "c", 
                        year = "d", 
                        episode = "d", 
                        word.beg = "d", 
                        word.end = "d", 
                        word.dur = "d", 
                        prec.seg.beg = "d", 
                        prec.seg.end = "d", 
                        foll.seg.beg = "d", 
                        foll.seg.end = "d", 
                        window = "d", 
                        vowels.per.second = "d", 
                        SUBTLEX.Zipf = "d", 
                        prev.dep.var.beg = "d", 
                        time.since.prev = "d", 
                        log.time.since.prev = "d", 
                        prec.vowel.dur = "d", 
                        foll.vowel.dur = "d", 
                        word.beg.norm = "d"))

# Convert string variables to factors
# (This code converts all named columns to factors at once)
DA_r <- DA_r %>% 
  mutate(across(colnames(DA_r)[colnames(DA_r) %in% 
                                 c("file",
                                   "series",
                                   "coder",
                                   "word",
                                   "style",
                                   "dep.var",
                                   "morpheme.boundary",
                                   "prec.seg",
                                   "foll.seg",
                                   "comments",
                                   "prev.dep.var")], factor))

# Group style into "onscreen" (human- + animal-directed + fourth-wall) vs. narration,
# and make it a factor, with narration as the reference level
DA_r <- DA_r %>%
  mutate(style.grouped = 
           case_when(
             style %in% c("animal-directed", "fourth-wall", "human-directed") ~ "onscreen",
             TRUE ~ as.character(style)),
         style.grouped = as.factor(style.grouped))

# Write data to file.
saveRDS(DA_r, here("data", "DA_r.rds"))
